/* ***************************************************************************
 *
 *    Copyright (C) 2006 OpenMI Association
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *    or look at URL www.gnu.org/licenses/lgpl.html
 *
 *    Contact info:
 *      URL: www.openmi.org
 *      Email: sourcecode@openmi.org
 *      Discussion forum available at www.sourceforge.net
 *
 *      Coordinator: Roger Moore, CEH Wallingford, Wallingford, Oxon, UK
 *
 *****************************************************************************
 *
 * These are added / extended interfaces that were derived from passed work
 * on Alterra projects were the Java implementation of OpenMI is used. The
 * interfaces in this package typically add convenience methods and at some
 * places more elaborate access to the classes in the backbone package.
 *
 * In general an <Interface>V2 extends an interface from the OpenMI standard
 * package (version 1.x). Interfaces without a V2 postfix are new.
 *
 * @author Rob Knapen, Alterra B.V., The Netherlands
 *
 ****************************************************************************/
package nl.alterra.openmi.sdk.extensions;

import java.util.Collection;

/**
 * Collection of IArgumentEx objects.
 */
public interface IArguments extends Collection<IArgumentEx> {

    /**
     * Returns the Value for the first found IArgument in the collection
     * that has the specified key.
     *
     * @param key
     * @return String Value, empty if key does not exist
     */
    public String getValueForKey(String key);

    /**
     * Changes the value of all arguments with the specified key and that
     * are not ReadOnly to the specified string.
     *
     * @param key
     * @param value
     */
    public void setValueForKey(String key, String value);

    /**
     * Returns true if the specified key exists in the collection.
     *
     * @param key
     * @return boolean, true if key exists
     */
    public boolean containsKey(String key);

    /**
     * Gets the index for a specified IArgumentEx in the collection.
     *
     * @param elem
     * @return int Index
     */
    public int indexOf(IArgumentEx elem);

    /**
     * Gets the IArgumentEx for the specified index.
     *
     * @return IArgumentEx The indexth argument
     */
    public IArgumentEx get(int index);
    
}
