/* ***************************************************************************
 *
 *    Copyright (C) 2006 OpenMI Association
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *    or look at URL www.gnu.org/licenses/lgpl.html
 *
 *    Contact info:
 *      URL: www.openmi.org
 *      Email: sourcecode@openmi.org
 *      Discussion forum available at www.sourceforge.net
 *
 *      Coordinator: Roger Moore, CEH Wallingford, Wallingford, Oxon, UK
 *
 *****************************************************************************
 *
 * These are added / extended interfaces that were derived from passed work
 * on Alterra projects were the Java implementation of OpenMI is used. The
 * interfaces in this package typically add convenience methods and at some
 * places more elaborate access to the classes in the backbone package.
 *
 * In general an <Interface>V2 extends an interface from the OpenMI standard
 * package (version 1.x). Interfaces without a V2 postfix are new.
 *
 * @author Rob Knapen, Alterra B.V., The Netherlands
 *
 ****************************************************************************/
package nl.alterra.openmi.sdk.extensions;

import org.openmi.standard.IArgument;


/**
 * Extended IArgument interface.
 */
public interface IArgumentEx extends IArgument {

    /**
     * Checks if key value equals the given value.
     *
     * @param key String to check
     * @return True if values are equal
     */
    public boolean equalsKey(String key);
    
    /**
     * Checks if "value" value equals the given value.
     *
     * @param value String to check
     * @return True if values are equal
     */
    public boolean equalsValue(String value);

    /**
     * Checks if key and "value" values are equal to the given values.
     *
     * @param key   String to check for key
     * @param value String to check for value
     * @return True if both values are equal
     */
    public boolean equalsKeyAndValue(String key, String value);
    
    /**
     * Sets the readSystemDeployer only state of the argument.
     *
     * @param readOnly The readSystemDeployer only state
     */
    public void setReadOnly(boolean readOnly);

    /**
     * Sets the key of the attribute.
     *
     * @param key String key to set
     */
    public void setKey(String key);

    /**
     * Sets the description for the attribute.
     *
     * @param description String description to set
     */
    public void setDescription(String description);
    
}
