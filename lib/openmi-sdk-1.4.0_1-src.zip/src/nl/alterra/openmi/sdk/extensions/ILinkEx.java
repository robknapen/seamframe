/* ***************************************************************************
 *
 *    Copyright (C) 2006 OpenMI Association
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *    or look at URL www.gnu.org/licenses/lgpl.html
 *
 *    Contact info:
 *      URL: www.openmi.org
 *      Email: sourcecode@openmi.org
 *      Discussion forum available at www.sourceforge.net
 *
 *      Coordinator: Roger Moore, CEH Wallingford, Wallingford, Oxon, UK
 *
 *****************************************************************************
 *
 * These are added / extended interfaces that were derived from passed work
 * on Alterra projects were the Java implementation of OpenMI is used. The
 * interfaces in this package typically add convenience methods and at some
 * places more elaborate access to the classes in the backbone package.
 *
 * In general an <Interface>V2 extends an interface from the OpenMI standard
 * package (version 1.x). Interfaces without a V2 postfix are new.
 *
 * @author Rob Knapen, Alterra B.V., The Netherlands
 *
 ****************************************************************************/
package nl.alterra.openmi.sdk.extensions;

import org.openmi.standard.IInputExchangeItem;
import org.openmi.standard.ILink;
import org.openmi.standard.IOutputExchangeItem;

/**
 * Extended link interface.
 */
public interface ILinkEx extends ILink {

    /**
     * Gets the ID of the object.
     *
     * @return String ID
     */
    public String getID();

    /**
     * Sets the ID of the instance to the specified value. Changing the ID is
     * not encouraged!
     *
     * @param id String ID to set
     */
    public void setID(String id);

    /**
     * Gets the description of the object. This is like an extended caption,
     * but might not be editable all the time by the user.
     *
     * @return String Description of the object
     */
    public String getDescription();

    /**
     * Sets the description of the object. This is like an extended caption,
     * but might not be editable all the time by the user.
     *
     * @param description The new description
     */
    public void setDescription(String description);

    /**
     * Gets the caption of the object. The caption is typically used for
     * display in an user interface, and the user might be allowed to change
     * it at will. So it is best to not rely on it to have a specific value.
     *
     * @return String The caption
     */
    public String getCaption();

    /**
     * Sets the caption of the object.
     *
     * @param caption The new caption
     */
    public void setCaption(String caption);

    /**
     * Gets the source exchange item the link is connected to.
     * 
     * Since OpenMI is a pull-based architecture the link's source is an
     * output exchange item (of a linkable component), and the target is
     * an input exchange item (of a linkable component).
     *
     * @return IOutputExchangeItem The link's source
     */
    public IOutputExchangeItem getSourceExchangeItem();

    /**
     * Gets the target exchange item the link is connected to.
     * 
     * Since OpenMI is a pull-based architecture the link's source is an
     * output exchange item (of a linkable component), and the target is
     * an input exchange item (of a linkable component).
     *
     * @return IInputExchangeItem The link's target
     */
    public IInputExchangeItem getTargetExchangeItem();

}
