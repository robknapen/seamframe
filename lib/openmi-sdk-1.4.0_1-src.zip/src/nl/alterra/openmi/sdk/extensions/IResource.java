/* ***************************************************************************
 *
 *    Copyright (C) 2006 OpenMI Association
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *    or look at URL www.gnu.org/licenses/lgpl.html
 *
 *    Contact info:
 *      URL: www.openmi.org
 *      Email: sourcecode@openmi.org
 *      Discussion forum available at www.sourceforge.net
 *
 *      Coordinator: Roger Moore, CEH Wallingford, Wallingford, Oxon, UK
 *
 *****************************************************************************
 *
 * These are added / extended interfaces that were derived from passed work
 * on Alterra projects were the Java implementation of OpenMI is used. The
 * interfaces in this package typically add convenience methods and at some
 * places more elaborate access to the classes in the backbone package.
 *
 * In general an <Interface>V2 extends an interface from the OpenMI standard
 * package (version 1.x). Interfaces without a V2 postfix are new.
 *
 * @author Rob Knapen, Alterra B.V., The Netherlands
 *
 ****************************************************************************/
package nl.alterra.openmi.sdk.extensions;

/**
 * Generic interface for Resource objects. A resource is considered to be
 * nothing more than a list of arguments. Since in our extended backbone and
 * standard interfaces an Argument can hold any type of object (not just a
 * String), a nested structure of IResources can be build and passed as an
 * OpenMI ValueSet.
 */
public interface IResource {

    /**
     * Gets the arguments for the Resource.
     *
     * @return IArguments The arguments added to the
     */
    public IArguments getArguments();

}