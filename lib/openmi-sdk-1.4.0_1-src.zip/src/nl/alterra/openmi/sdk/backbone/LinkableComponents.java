/* ***************************************************************************
 *
 *    Copyright (C) 2006 OpenMI Association
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *    or look at URL www.gnu.org/licenses/lgpl.html
 *
 *    Contact info:
 *      URL: www.openmi.org
 *      Email: sourcecode@openmi.org
 *      Discussion forum available at www.sourceforge.net
 *
 *      Coordinator: Roger Moore, CEH Wallingford, Wallingford, Oxon, UK
 *
 *****************************************************************************
 *
 * @author Rob Knapen, Alterra B.V., The Netherlands
 *
 ****************************************************************************/
package nl.alterra.openmi.sdk.backbone;

import java.util.ArrayList;
import org.openmi.standard.IArgument;
import org.openmi.standard.ILinkableComponent;
import nl.alterra.openmi.sdk.extensions.IArguments;
import nl.alterra.openmi.sdk.extensions.ILinkableComponentEx;

/**
 * Typesafe collection of ILinkableComponents.
 */
public class LinkableComponents extends ArrayList<ILinkableComponent> {
    
    /**
     * Gets the combined list of the initialisation arguments required by the
     * components in the collection. Duplicates are allowed.
     *
     * @return IArguments The required properties
     */
    public IArguments getInitialisationArguments() {
        Arguments args = new Arguments();

        for (ILinkableComponent lc : this) {
            if (lc instanceof ILinkableComponentEx) {
                for (IArgument a : ((ILinkableComponentEx) lc).getInitialisationArguments()) {
                    args.add(a);
                }
            }
        }
        return args;
    }

    /**
     * Gets the combined list of custom arguments, which are returned as
     * an IArguments. All the arguments from the contained components are
     * collected and returned with the duplicates removed.
     *
     * @return IArguments The custom arguments
     */
    public IArguments getCustomArguments() {
        Arguments attr = new Arguments();
        for (ILinkableComponent lc : this) {
            if (lc instanceof ILinkableComponentEx) {
                attr.addAll(((ILinkableComponentEx) lc).getCustomArguments());
            }
        }
        return attr;
    }

}