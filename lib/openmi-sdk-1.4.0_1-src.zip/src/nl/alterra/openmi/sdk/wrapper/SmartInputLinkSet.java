/* ***************************************************************************
 *
 *    Copyright (C) 2006 OpenMI Association
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation; either
 *    version 2.1 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *    or look at URL www.gnu.org/licenses/lgpl.html
 *
 *    Contact info:
 *      URL: www.openmi.org
 *      Email: sourcecode@openmi.org
 *      Discussion forum available at www.sourceforge.net
 *
 *      Coordinator: Roger Moore, CEH Wallingford, Wallingford, Oxon, UK
 *
 *****************************************************************************
 *
 * The classes in the utilities package are mostly a direct translation from
 * the C# version. They successfully pass the unit tests (which were also
 * taken from the C# version), but so far no extensive time as been put into
 * them.
 *
 ****************************************************************************/
package nl.alterra.openmi.sdk.wrapper;

import org.openmi.standard.ILink;

/**
 * SmartInputLinkSet class
 * a part of the smart wrapper engine
 */
public class SmartInputLinkSet extends SmartLinkSet implements java.io.Serializable {
    
    /**
     * To add a new link
     *
     * @param link the new link
     */
    public void addLink(ILink link) {
        SmartInputLink smartInputLink = new SmartInputLink();
        smartInputLink.link = link;
        //smartInputLink.baseEvents = baseEvents;
        smartInputLink.initialize(engineApiAccess);
        smartLinkList.add(smartInputLink);
    }

    /**
     * To upadate the input
     *
     * @throws Exception
     */
    public void updateInput() throws Exception {
        for (int i = 0; i < smartLinkList.size(); i++) {
            ((SmartInputLink) smartLinkList.get(i)).updateInput(engineApiAccess.getInputTime(((SmartInputLink) smartLinkList.get(i)).link.getTargetQuantity().getID(),
                    ((SmartInputLink) smartLinkList.get(i)).link.getTargetElementSet().getID()));
        }
    }

}